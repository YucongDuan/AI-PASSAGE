
import json, sys, tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'src'))
from aipassage.core import *

def load_example(name): return json.loads((root/'examples'/'deployments'/name).read_text(encoding='utf-8'))
checks=[]
def c(name,cond): checks.append((name,bool(cond)))

c('selftest',selftest()['passed'])
c('packs',len(load_packs())==12)
c('sources',len(load_sources())==23)
c('shocks',len(load_shocks())==8)
r=assess(load_example('global_support_agent.json'))
c('global_has_cn',any(x['code']=='CN' for x in r['jurisdictions']))
c('global_holds',r['overall_route'] in ('HOLD','STOP'))
c('global_adapters',len(r['required_adapters'])>=4)
r2=assess(load_example('local_research_copilot.json'))
c('local_vector',r2['semantic_vector'].startswith('1'))
s=shock(load_example('global_support_agent.json'),'FOREIGN_API_BAN')
c('shock_trigger',s['scenarios'][0]['triggered'])
with tempfile.TemporaryDirectory() as td:
    b=build_bundle(load_example('local_research_copilot.json'),r2,Path(td)/'b.zip')
    c('bundle',b['members']==7 and Path(b['file']).exists())
for n,v in checks: print(('PASS' if v else 'FAIL'),n)
print(sum(v for _,v in checks),'passed,',sum(not v for _,v in checks),'failed')
raise SystemExit(0 if all(v for _,v in checks) else 1)
