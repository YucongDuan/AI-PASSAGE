# Portable AI Deployment Passport

A passport records the AI system, roles, use cases, affected people, model provider, hosting, data flows, agentic actions, consequential decisions, human review, appeals, logging, incident response, labeling, local representation, export-control dependencies and fallback paths. A passport is an input to review, not proof of compliance.
