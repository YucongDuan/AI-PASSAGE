
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from .core import *

def emit(x): print(json.dumps(x,ensure_ascii=False,indent=2))

def main(argv=None):
    p=argparse.ArgumentParser(prog='ai-passage',description='Cross-jurisdiction AI restriction resilience router')
    sub=p.add_subparsers(dest='cmd',required=True)
    for n in ['summary','list-packs','list-shocks','selftest']: sub.add_parser(n)
    x=sub.add_parser('show-pack'); x.add_argument('code')
    x=sub.add_parser('assess'); x.add_argument('manifest'); x.add_argument('--packs',default=''); x.add_argument('--out')
    x=sub.add_parser('shock'); x.add_argument('manifest'); x.add_argument('--scenario'); x.add_argument('--out')
    x=sub.add_parser('bundle'); x.add_argument('manifest'); x.add_argument('--packs',default=''); x.add_argument('--out',required=True)
    x=sub.add_parser('diff'); x.add_argument('pack_a'); x.add_argument('pack_b')
    x=sub.add_parser('serve'); x.add_argument('--directory',default='site'); x.add_argument('--host',default='127.0.0.1'); x.add_argument('--port',type=int,default=8484)
    a=p.parse_args(argv)
    if a.cmd=='summary': emit(summary())
    elif a.cmd=='list-packs': emit([{k:x[k] for k in ['code','id','jurisdiction','status','snapshot_date','review_after']} for x in load_packs()])
    elif a.cmd=='list-shocks': emit(load_shocks())
    elif a.cmd=='selftest':
        r=selftest(); emit(r); return 0 if r['passed'] else 1
    elif a.cmd=='show-pack':
        for x in load_packs():
            if a.code in (x['code'],x['id']): emit(x); return 0
        raise SystemExit('pack not found')
    elif a.cmd in ('assess','shock','bundle'):
        m=json.loads(Path(a.manifest).read_text(encoding='utf-8'))
        codes=[x.strip() for x in a.packs.split(',') if x.strip()] if hasattr(a,'packs') else None
        if a.cmd=='assess': r=assess(m,codes); Path(a.out).write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8') if a.out else emit(r)
        elif a.cmd=='shock':
            r=shock(m,a.scenario); Path(a.out).write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8') if a.out else emit(r)
        else:
            r=assess(m,codes); emit(build_bundle(m,r,a.out))
    elif a.cmd=='diff': emit(pack_diff(json.loads(Path(a.pack_a).read_text(encoding='utf-8')),json.loads(Path(a.pack_b).read_text(encoding='utf-8'))))
    elif a.cmd=='serve':
        import os; os.chdir(a.directory); print(f'http://{a.host}:{a.port}'); ThreadingHTTPServer((a.host,a.port),SimpleHTTPRequestHandler).serve_forever()
    return 0
