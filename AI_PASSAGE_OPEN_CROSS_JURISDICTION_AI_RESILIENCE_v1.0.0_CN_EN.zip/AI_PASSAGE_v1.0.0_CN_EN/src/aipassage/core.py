
from __future__ import annotations
import json, hashlib, csv, io, zipfile
from pathlib import Path
from importlib.resources import files
from datetime import date

SEVERITY={"INFO":0,"OPEN":0,"ADAPT":1,"LOCALIZE":2,"PARTNER":3,"HOLD":4,"STOP":5}

def _load_json(path): return json.loads(path.read_text(encoding="utf-8"))
def data_path(*parts): return files("aipassage").joinpath("data",*parts)
def load_sources(): return json.loads(data_path("sources.json").read_text(encoding="utf-8"))
def load_shocks(): return json.loads(data_path("shocks.json").read_text(encoding="utf-8"))
def load_adapters(): return json.loads(data_path("adapters.json").read_text(encoding="utf-8"))
def load_packs():
    root=data_path("packs")
    out=[]
    for p in sorted(root.iterdir(), key=lambda x:x.name):
        if p.name.endswith('.json'): out.append(json.loads(p.read_text(encoding='utf-8')))
    return out

def digest(obj):
    return hashlib.sha256(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode()).hexdigest()

def getv(obj,path,default=None):
    cur=obj
    for part in path.split('.'):
        if not isinstance(cur,dict) or part not in cur: return default
        cur=cur[part]
    return cur

def match(cond,obj):
    if cond is None: return True
    if 'all' in cond: return all(match(x,obj) for x in cond['all'])
    if 'any' in cond: return any(match(x,obj) for x in cond['any'])
    if 'not' in cond: return not match(cond['not'],obj)
    value=getv(obj,cond.get('field',''))
    if 'eq' in cond: return value==cond['eq']
    if 'truthy' in cond: return bool(value)==bool(cond['truthy'])
    if 'contains' in cond: return isinstance(value,(list,str)) and cond['contains'] in value
    if 'intersects' in cond: return isinstance(value,list) and bool(set(value)&set(cond['intersects']))
    if 'in' in cond: return value in cond['in']
    return False

def semantic_vector(m):
    gaps={k:[] for k in 'DIKWP'}
    # D: identity/provenance and data path
    for path,label in [('id','deployment id'),('name','deployment name'),('architecture.provider_country','provider country'),('architecture.hosting_countries','hosting countries'),('data.data_flow_documented','data flow documentation')]:
        v=getv(m,path)
        if v in (None,'',[],False): gaps['D'].append(label)
    # I: differences and affected groups
    if not getv(m,'target_jurisdictions',[]): gaps['I'].append('target jurisdictions')
    if not getv(m,'sectors',[]): gaps['I'].append('sectors')
    if not getv(m,'governance.affected_groups',[]): gaps['I'].append('affected groups')
    # K: complete architecture envelope
    for path,label in [('architecture.model_replaceable','model replaceability'),('architecture.logging','logging'),('architecture.incident_response','incident response'),('architecture.kill_switch','kill switch')]:
        if getv(m,path) is not True: gaps['K'].append(label)
    # W: values/owners/beneficiaries
    if not getv(m,'governance.owner'): gaps['W'].append('accountable owner')
    if not getv(m,'governance.beneficiaries',[]): gaps['W'].append('beneficiaries')
    if not getv(m,'governance.affected_groups',[]): gaps['W'].append('affected groups')
    # P: change/fallback process
    if getv(m,'governance.fallback_plan') is not True: gaps['P'].append('fallback plan')
    if getv(m,'governance.rule_monitoring') is not True: gaps['P'].append('rule monitoring')
    if not getv(m,'governance.review_date'): gaps['P'].append('review date')
    vector=''.join('1' if not gaps[k] else '0' for k in 'DIKWP')
    return vector,gaps

def assess(manifest, selected_codes=None):
    packs=load_packs(); codes=set(selected_codes or manifest.get('target_jurisdictions',[]))
    # Always add export pack if triggered
    if getv(manifest,'infrastructure.us_origin_advanced_compute') or getv(manifest,'infrastructure.us_origin_chip_dependency'): codes.add('US-BIS')
    routes=[]; unresolved=[]; applied=[]
    for pack in packs:
        if pack['code'] not in codes: continue
        applied.append(pack['id'])
        obs=[]; highest=pack.get('baseline','OPEN')
        for o in pack.get('obligations',[]):
            if match(o.get('when'),manifest):
                obs.append(o)
                if SEVERITY.get(o['level'],0)>SEVERITY.get(highest,0): highest=o['level']
                if o.get('legal_review'): unresolved.append({'jurisdiction':pack['code'],'obligation':o['id'],'reason':'professional review required'})
        routes.append({'pack_id':pack['id'],'code':pack['code'],'jurisdiction':pack['jurisdiction'],'status':pack['status'],'route':highest,'snapshot_date':pack['snapshot_date'],'review_after':pack['review_after'],'summary_cn':pack['summary_cn'],'obligations':obs,'source_ids':pack['source_ids']})
    vector,gaps=semantic_vector(manifest)
    for pos,items in gaps.items():
        for item in items: unresolved.append({'position':pos,'reason':item})
    adapter_ids=[]
    mapping={
      'content_labeling':['LABELING'],'content_labeling_cn':['LABELING'],'content_labeling_kr':['LABELING'],
      'high_risk_bundle':['HUMAN_GATE','PROVENANCE_LEDGER','INCIDENT_RESPONSE'],
      'high_impact_kr':['HUMAN_GATE','PROVENANCE_LEDGER'],'cn_scope_and_filing':['LOCAL_REPRESENTATIVE','PROVENANCE_LEDGER'],
      'data_partition_cn':['DATA_PARTITION','LOCAL_RUNTIME'],'compute_fallback':['MODEL_SWAP','LOCAL_RUNTIME','NON_AI_FALLBACK'],
      'export_control_review':['PROVENANCE_LEDGER'],'state_overlay':['PROVENANCE_LEDGER'],
      'public_sector_pack':['LOCAL_REPRESENTATIVE','PROVENANCE_LEDGER'],'consequential_decision_pack':['HUMAN_GATE','PROVENANCE_LEDGER'],
      'frontier_safety_framework':['INCIDENT_RESPONSE','PROVENANCE_LEDGER'],'agentic_governance':['HUMAN_GATE','INCIDENT_RESPONSE'],
      'companion_ai_guardrails':['HUMAN_GATE','FEATURE_SWITCH','INCIDENT_RESPONSE'],'disable_feature':['FEATURE_SWITCH'],
    }
    for r in routes:
        for o in r['obligations']:
            adapter_ids += mapping.get(o.get('adapter'),[])
    adapter_ids=list(dict.fromkeys(adapter_ids))
    result={
      'system':'AI PASSAGE','version':'1.0.0','snapshot_date':'2026-08-18',
      'deployment':{'id':manifest.get('id'),'name':manifest.get('name'),'digest':digest(manifest)},
      'semantic_vector':vector,'semantic_gaps':gaps,'applied_packs':applied,
      'jurisdictions':routes,'required_adapters':adapter_ids,'unresolved':unresolved,
      'overall_route':max([r['route'] for r in routes],key=lambda x:SEVERITY.get(x,0),default='OPEN'),
      'disclaimer':'Operational routing aid only. Not legal advice, certification, export classification, or authorization.'
    }
    result['assessment_digest']=digest(result)
    return result

def shock(manifest, scenario_id=None):
    out=[]
    for s in load_shocks():
        if scenario_id and s['id']!=scenario_id: continue
        triggered=[p for p in s['triggers'] if bool(getv(manifest,p))]
        out.append({'id':s['id'],'title_cn':s['title_cn'],'triggered':bool(triggered),'matched_fields':triggered,'actions':s['actions'],'description_cn':s['description_cn']})
    return {'deployment':manifest.get('id'),'scenarios':out,'digest':digest(out)}

def pack_diff(a,b):
    def keyobs(p): return {x['id']:x for x in p.get('obligations',[])}
    aa,bb=keyobs(a),keyobs(b)
    return {'pack_a':a['id'],'pack_b':b['id'],'added':sorted(set(bb)-set(aa)),'removed':sorted(set(aa)-set(bb)),'changed':sorted(k for k in set(aa)&set(bb) if digest(aa[k])!=digest(bb[k])),'status_changed':a.get('status')!=b.get('status'),'review_after_changed':a.get('review_after')!=b.get('review_after')}

def result_csv(result):
    s=io.StringIO(); w=csv.writer(s)
    w.writerow(['jurisdiction_code','jurisdiction','route','status','obligation_id','category','level','title_cn','legal_review'])
    for r in result['jurisdictions']:
        if not r['obligations']: w.writerow([r['code'],r['jurisdiction'],r['route'],r['status'],'','','','',''])
        for o in r['obligations']:
            w.writerow([r['code'],r['jurisdiction'],r['route'],r['status'],o['id'],o['category'],o['level'],o['title_cn'],o.get('legal_review',False)])
    return s.getvalue()

def build_bundle(manifest,result,out_path):
    out_path=Path(out_path); out_path.parent.mkdir(parents=True,exist_ok=True)
    srcs=load_sources(); shocks=shock(manifest)
    fileset={
      'deployment_passport.json':json.dumps(manifest,ensure_ascii=False,indent=2),
      'route_assessment.json':json.dumps(result,ensure_ascii=False,indent=2),
      'obligation_matrix.csv':result_csv(result),
      'shock_simulation.json':json.dumps(shocks,ensure_ascii=False,indent=2),
      'official_source_ledger.json':json.dumps(srcs,ensure_ascii=False,indent=2),
      'README.txt':'AI PASSAGE evidence bundle. Operational routing aid only; not legal advice or certification.\n'
    }
    manifest_rows=[]
    for name,text in fileset.items(): manifest_rows.append({'file':name,'sha256':hashlib.sha256(text.encode()).hexdigest(),'bytes':len(text.encode())})
    fileset['BUNDLE_MANIFEST.json']=json.dumps({'files':manifest_rows,'root_digest':digest(manifest_rows)},ensure_ascii=False,indent=2)
    with zipfile.ZipFile(out_path,'w',zipfile.ZIP_DEFLATED) as z:
        for name,text in fileset.items(): z.writestr(name,text)
    return {'file':str(out_path),'sha256':hashlib.sha256(out_path.read_bytes()).hexdigest(),'members':len(fileset)}

def summary():
    packs=load_packs(); src=load_sources(); shocks=load_shocks()
    return {'system':'AI PASSAGE','version':'1.0.0','snapshot_date':'2026-08-18','jurisdiction_packs':len(packs),'official_sources':len(src),'shock_scenarios':len(shocks),'pack_codes':[p['code'] for p in packs],'core_digest':digest({'packs':packs,'sources':src,'shocks':shocks})}

def selftest():
    errors=[]
    packs=load_packs()
    if len(packs)!=12: errors.append('pack_count')
    if len(load_sources())<20: errors.append('source_count')
    if len(load_shocks())!=8: errors.append('shock_count')
    codes=[p['code'] for p in packs]
    if len(codes)!=len(set(codes)): errors.append('duplicate_codes')
    # load bundled sample through package path is tested externally
    for p in packs:
        if not p['obligations']: errors.append('empty:'+p['id'])
        for o in p['obligations']:
            if o['level'] not in SEVERITY: errors.append('level:'+o['id'])
    return {'passed':not errors,'errors':errors,'checks':5+sum(len(p['obligations']) for p in packs),'summary':summary()}
