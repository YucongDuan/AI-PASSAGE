# Sovereign Adapter Contract

Every adapter must identify: trigger, jurisdiction, owner, inputs, outputs, tests, fallback, rollback, residual risk, data location and evidence produced. Adapters must remain model-neutral where feasible.
