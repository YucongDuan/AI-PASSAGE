# AI PASSAGE｜AI通路

**一个AI系统，多种规则，始终保留退路。**

AI PASSAGE 是一个离线、可审计、可更新的跨法域 AI 限制韧性与主权部署路由系统。它不承诺“自动合规”，而是把一个 AI 产品拆成模型、数据、托管、工具、用途、用户、责任和回退路径，再加载版本化法域规则包，输出：

- 每个市场的 `OPEN / ADAPT / LOCALIZE / PARTNER / HOLD / STOP` 路由；
- 必须完成的义务、需要专业审查的未知项；
- 模型替换、数据分区、内容标识、人类复核、事件响应等架构适配；
- 外国API禁用、数据出境冻结、芯片限制等冲击模拟；
- 可携带的部署证据包。

## 快速运行

```bash
python dist/AIPassage.pyz summary
python dist/AIPassage.pyz assess examples/deployments/global_support_agent.json --out run.json
python dist/AIPassage.pyz shock examples/deployments/global_support_agent.json
python dist/AIPassage.pyz bundle examples/deployments/global_support_agent.json --out evidence_bundle.zip
python dist/AIPassage.pyz selftest
```

直接打开 `site/index.html` 使用离线交互系统。

## 重要边界

- 规则快照日期：2026-08-18；复核建议日期：2026-11-18。
- 本系统不是法律意见、认证、出口分类、备案批准或市场准入授权。
- 规则包只提供结构化触发和官方来源入口；高风险结论必须由有权主体和专业人士核验。
- 美国部署必须加载州法和行业叠加；出口管制不得由本系统自动结论化。
- 公开代码采用 Apache-2.0；AI PASSAGE 名称、标识和任何官方背书不因代码许可自动授权。
