# Rule Pack Update Protocol

1. Use primary official sources.
2. Separate `BINDING`, `TRANSITION`, `GUIDANCE`, `DRAFT`, and `POLICY`.
3. Freeze `snapshot_date`, `effective_date`, `review_after`, source URLs and summaries.
4. Never silently replace old packs; add a new version and publish a diff.
5. Mark `legal_review=true` when the system cannot safely decide scope or effect.
6. Re-review a pack at least every 90 days, and immediately after a major legal or policy event.
7. Do not encode a news headline as a prohibition.
8. Preserve uncertainty and conflicting official dates as explicit records.

Current snapshot: 2026-08-18.
