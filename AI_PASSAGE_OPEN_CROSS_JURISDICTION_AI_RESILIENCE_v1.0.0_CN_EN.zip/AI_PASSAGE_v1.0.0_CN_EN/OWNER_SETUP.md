# Owner Setup

Before public launch, configure: repository owner, public contact, authorized contracting entity, privacy contact, security reporting channel, rule-pack maintainers, professional-review partners, and trademark/branding policy. Do not add payment links until an authorized entity can contract, invoice, deliver and handle liability.
