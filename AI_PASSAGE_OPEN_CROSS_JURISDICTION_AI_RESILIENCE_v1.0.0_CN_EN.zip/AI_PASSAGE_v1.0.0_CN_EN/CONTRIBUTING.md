# Contributing

Contributions are welcome for rule-pack updates, architecture adapters, translations, tests and evidence-bundle tooling. Every rule change must include: jurisdiction, official source URL, publication/effective dates, binding status, scope, change summary, reviewer and next-review date. News articles alone are insufficient.
