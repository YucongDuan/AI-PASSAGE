# Official source ledger

- [S01] **European Commission — EU AI Act regulatory framework**  
  https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai  
  AI Act于2024年8月1日生效；大部分规则自2026年8月2日起适用，部分义务更早或更晚。
- [S02] **European Commission — Navigating the AI Act**  
  https://digital-strategy.ec.europa.eu/en/faqs/navigating-ai-act  
  透明度义务与高风险系统实施说明。
- [S03] **European Commission — Code of Practice on Transparency of AI-generated Content**  
  https://digital-strategy.ec.europa.eu/en/policies/code-practice-ai-generated-content  
  2026年8月2日起适用的AI生成内容透明度义务辅助材料。
- [S04] **国家互联网信息办公室等七部门 — 生成式人工智能服务管理暂行办法**  
  https://www.cac.gov.cn/2023-07/13/c_1690898327029107.htm  
  面向境内公众提供生成式人工智能服务的管理要求。
- [S05] **国家互联网信息办公室等四部门 — 人工智能生成合成内容标识办法**  
  https://www.cac.gov.cn/2025-03/14/c_1743654684782215.htm  
  显式、隐式标识及相关主体责任，自2025年9月1日起实施。
- [S06] **国家互联网信息办公室 — 生成式人工智能服务备案信息公告（2026年3月至4月）**  
  https://www.cac.gov.cn/2026-05/13/c_1780413225190669.htm  
  备案、应用登记及上线公示要求的最新公开样本。
- [S07] **国家互联网信息办公室 — 人工智能拟人化互动服务管理暂行办法**  
  https://www.cac.gov.cn/2026-04/10/c_1777558395078289.htm  
  持续性情感互动和拟人化服务的专项规则。
- [S08] **Republic of Korea, Ministry of Science and ICT — AI Basic Act and Enforcement Decree come into force**  
  https://www.msit.go.kr/eng/bbs/view.do?bbsSeqNo=42&mId=4&mPid=2&nttSeqNo=1214&sCode=eng  
  AI基本法及施行令于2026年1月22日生效。
- [S09] **Republic of Korea, Ministry of Science and ICT — Guidelines on Ensuring AI Transparency**  
  https://www.msit.go.kr/eng/bbs/view.do?bbsSeqNo=42&mId=4&nttSeqNo=1215&sCode=eng  
  生成式AI标识等透明度义务实施指引。
- [S10] **Cabinet Office, Government of Japan — Guideline under Japan AI Act (Act No. 53 of 2025)**  
  https://www8.cao.go.jp/cstp/ai/ai_guideline/ai_gl_2025g_draft2_en.pdf  
  基于2025年AI促进法的适当研究开发与利用指引。
- [S11] **Cabinet Office, Government of Japan — Japan's Second AI Basic Plan**  
  https://www8.cao.go.jp/cstp/ai/ai_plan/aiplan_eng_20260714.pdf  
  2026年更新的AI基本计划。
- [S12] **The White House — America's AI Action Plan**  
  https://www.whitehouse.gov/releases/2025/07/white-house-unveils-americas-ai-action-plan/  
  美国联邦层面的创新、基础设施和国际战略政策。
- [S13] **U.S. Bureau of Industry and Security — BIS rescinds AI Diffusion Rule and strengthens chip controls**  
  https://www.bis.gov/press-release/department-commerce-announces-rescission-biden-era-artificial-intelligence-diffusion-rule-strengthens  
  AI扩散规则被撤销，但先进计算与芯片相关出口管制继续变化。
- [S14] **U.S. Bureau of Industry and Security — BIS Guidance — May 31, 2026**  
  https://www.bis.gov/media/documents/bis-guidance-may-31-2026.pdf  
  先进计算项目对部分目的地及总部/母公司关系的许可证要求说明。
- [S15] **State of California — Governor signs SB 53**  
  https://www.gov.ca.gov/2025/09/29/governor-newsom-signs-sb-53-advancing-californias-world-leading-artificial-intelligence-industry/  
  前沿AI开发者安全框架、重大事件报告和举报者保护。
- [S16] **Colorado General Assembly — SB24-205 Consumer Protections for Artificial Intelligence**  
  https://leg.colorado.gov/bills/sb24-205  
  高风险AI、影响评估、通知、数据纠正和人工申诉等要求；后续立法存在变动。
- [S17] **Colorado Attorney General — Colorado Attorney General AI rulemaking portal**  
  https://coag.gov/ai/  
  反歧视AI规则制定与后续法案变化入口。
- [S18] **Texas Legislature — Texas Responsible Artificial Intelligence Governance Act**  
  https://capitol.texas.gov/tlodocs/89R/billtext/html/HB00149F.htm  
  HB149于2026年1月1日生效，包含消费者保护、禁止用途、监管沙盒等。
- [S19] **UK Government — AI regulation: a pro-innovation approach**  
  https://www.gov.uk/government/publications/ai-regulation-a-pro-innovation-approach  
  英国以现有监管机构和行业规则为主的促进创新框架。
- [S20] **UK AI Security Institute — AI Security Institute**  
  https://www.aisi.gov.uk/  
  高级AI能力、影响与风险缓释研究。
- [S21] **Infocomm Media Development Authority — Model AI Governance Framework for Agentic AI**  
  https://www.imda.gov.sg/resources/press-releases-factsheets-and-speeches/press-releases/2026/new-model-ai-governance-framework-for-agentic-ai  
  2026年面向智能体AI的企业治理框架。
- [S22] **Australian Government, Department of Industry — Guidance for AI adoption**  
  https://www.industry.gov.au/publications/guidance-for-ai-adoption  
  面向复杂和较高风险AI应用的治理实施指导。
- [S23] **Australian Government — Mandatory guardrails consultation**  
  https://consult.industry.gov.au/ai-mandatory-guardrails  
  高风险AI强制护栏仍需区分提案、咨询与已生效义务。