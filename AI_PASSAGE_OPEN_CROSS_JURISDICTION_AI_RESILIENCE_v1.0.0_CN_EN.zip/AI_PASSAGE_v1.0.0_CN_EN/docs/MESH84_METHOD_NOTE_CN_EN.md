# Mesh8.4 Method Note

AI PASSAGE uses D/I/K/W/P internally without exposing a new semantic authority in the public brand. D preserves deployment identity and source. I preserves jurisdictional differences and unresolved conflicts. K forms a bounded deployment envelope. W records local rights, security and public values. P records adaptation, deployment, monitoring, rollback and correction. `11111` means the passport is structurally ready for routing; it does not mean legal compliance.
