# Security

Do not submit personal data, trade secrets, export-controlled data, credentials or non-public regulatory communications in public issues. Rule-pack corrections should cite public official sources. Security issues should be reported privately to the repository owner after contact details are configured.
