# Code of Conduct

Be precise, civil and evidence-based. Do not use the project to stigmatize countries, providers, models or users. Distinguish binding law, draft law, guidance, procurement policy and technical recommendation.
